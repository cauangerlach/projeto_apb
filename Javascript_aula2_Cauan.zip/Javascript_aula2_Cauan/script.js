function mostraData(){
    document.getElementById("data").innerHTML = Date();
}

function mostraMensagem() {
    alert('Estou aprendendo a programar em JavaScript!');
}